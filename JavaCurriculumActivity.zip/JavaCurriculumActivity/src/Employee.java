import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Employee {
    private JPanel Main;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton saveButton;
    private JTable table1;
    private JButton updateButton;
    private JButton deleteButton;
    private JButton searchButton;
    private JTextField textIdTextField;
    private JScrollPane table_1;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Employee");
        frame.setContentPane(new Employee().Main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    Connection con;
    PreparedStatement pst;
    public void connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/rbcompany", "root","");
            System.out.println("connection is established Successfully!");
        }
        catch (ClassNotFoundException ex)
        {
            ex.printStackTrace();

        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        }
    }
    void table_load()
    {
        try
        {
            pst = con.prepareStatement("select * from employee2");
            ResultSet rs = pst.executeQuery();
            table1.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public Employee() {
        connect();
        table_load();
    saveButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            String EmpName,salary,contact;
            EmpName = textField1.getName();
            salary = textField2.getText();
            contact = textField3.getText();

            try {
                pst = con.prepareStatement("insert into Employee2(EmpName,salary,contact)values(?,?,?)");
                pst.setString(1, EmpName);
                pst.setString(2, salary);
                pst.setString(3, contact);
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Record Added!!!!!");
                table_load();
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField1.requestFocus();
            }

            catch (SQLException e1)
            {

                e1.printStackTrace();
            }

        }

    });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    String EmpId = textIdTextField.getText();

                    pst = con.prepareStatement("select EmpName,salary,contact from employee2 where id = ?");
                    pst.setString(1, EmpId);
                    ResultSet rs = pst.executeQuery();

                    if(rs.next()==true)
                    {
                        String EmpName = rs.getString(1);
                        String salary = rs.getString(2);
                        String contact = rs.getString(3);

                        textField1.setText(EmpName);
                        textField2.setText(salary);
                        textField3.setText(contact);

                    }
                    else
                    {
                        textField1.setText("");
                        textField2.setText("");
                        textField3.setText("");
                        JOptionPane.showMessageDialog(null,"Invalid Employee No");

                    }
                }
                catch (SQLException ex)
                {
                    ex.printStackTrace();
                }
            }

        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String EmpId,EmpName,salary,contact;
                EmpName = textField1.getText();
                salary = textField2.getText();
                contact = textField3.getText();
                EmpId = textIdTextField.getText();
                try {
                    pst = con.prepareStatement("update employee2 set EmpName = ?,salary = ?,contact = ? where id = ?");
                    pst.setString(1, EmpName);
                    pst.setString(2, salary);
                    pst.setString(3, contact);
                    pst.setString(4, EmpId);

                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Record Updated!!!!!");
                    table_load();
                    textField1.setText("");
                    textField2.setText("");
                    textField3.setText("");
                    textField1.requestFocus();
                }

                catch (SQLException e1)
                {
                    e1.printStackTrace();
                }
            }


        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String EmpId;
                EmpId = textIdTextField.getText();

                try {
                    pst = con.prepareStatement("delete from employee2  where id = ?");

                    pst.setString(1, EmpId);

                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Record Deleted!!!!!");
                    table_load();
                    textField1.setText("");
                    textField2.setText("");
                    textField3.setText("");
                    textField1.requestFocus();
                }

                catch (SQLException e1)
                {

                    e1.printStackTrace();
                }
            }

        });
    }
}
